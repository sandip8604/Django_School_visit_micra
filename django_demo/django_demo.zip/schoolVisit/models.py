from django.db import models
from django.contrib.auth.models import AbstractUser

class School(models.Model):
    name = models.CharField(max_length=100)
    city = models.CharField(max_length=100)
    principal = models.CharField(max_length=100)
    contact = models.CharField(max_length=15)
    address = models.TextField(null=True)

    def __str__(self):
        return self.name

    
class User(models.Model):
    ROLE_CHOICES = [
        ('admin', 'Admin'),
        ('staff', 'Staff'),
    ]
    
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=100)
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    email = models.EmailField()
    role = models.CharField(max_length=20, choices=ROLE_CHOICES)
    

    
class Visit(models.Model):
    STATUS = [
        ('planned','Planned'),
        ('done','Done'),
    ]

    school = models.ForeignKey(School, on_delete=models.CASCADE)
    officer = models.ForeignKey(User, on_delete=models.CASCADE)
    visit_date = models.DateField()
    purpose = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS)


